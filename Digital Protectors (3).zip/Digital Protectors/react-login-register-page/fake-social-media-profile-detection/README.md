# Detecting Fake Social Media Profile - Twitter data

datset description: https://developer.twitter.com/en/docs/twitter-api/v1/data-dictionary/object-model/user

1) Input required user profile data in the prediction_df inside the fake_profile_ann.py
2) Run fake_profile_ann.py to make prediction
