import React from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'

import LandingPage from './components/pages/LandingPage'
import LoginPage from './components/pages/LoginPage'
import RegisterPage from './components/pages/RegisterPage'
import ForgetPasswordPage from './components/pages/ForgetPasswordPage'
import HomePage from './components/pages/HomePage'

import './App.css'
import gauardYourP from './components/pages/gauardYourP'
import realFake from './components/pages/realFake'
import accSearched from './components/pages/accSearched'
import stats from './components/pages/stats'
import video from './components/pages/video'
import news from './components/pages/news'
import report from './components/pages/report'
import chatBot from './components/pages/chatBot'

export default function App() {
    return (
        <Router>
            <div>
                <Switch>
                    <Route exact path="/" component={ LandingPage } />
                    <Route path="/login" component={ LoginPage } />
                    <Route path="/register" component={ RegisterPage } />
                    <Route path="/forget-password" component={ ForgetPasswordPage } />
                    <Route path="/home" component={ HomePage } />
                    <Route path="/guard" component={ gauardYourP} />
                    <Route path="/realFake" component={ realFake} />
                    <Route path="/searcgAcc" component={ accSearched} />
                    <Route path="/stat" component={ stats} />
                    <Route path="/video" component={ video} />
                    <Route path="/newss" component={ news} />
                    <Route path="/report" component={ report} />
                    <Route path="/chat" component={ chatBot} />

                </Switch>
            </div>
        </Router>
    )
}