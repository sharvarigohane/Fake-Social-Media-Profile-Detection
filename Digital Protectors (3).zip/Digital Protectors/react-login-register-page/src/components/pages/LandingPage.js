import React from 'react'
import { Link } from 'react-router-dom'

import '../../App.css'
import './landingPage.css'
import BackgroundImage from '../../assets/images/landingPageImage.jpg'
// C:\Users\ASUS\OneDrive\Desktop\tp\reactmm\react-login-register-page\src\assets\images\landingPageImage.jpg

export default function LandingPage() {
    
    return (
        <div style={homeDiv}>
            <Link to="/login">
                <button class="homeButton bt1">Log In</button>
            </Link>
            <Link to="/register">
                <button class="homeButton bt2">Register</button>
            </Link>
        </div>
    )
}

const homeDiv = {
    height: "100vh",
    width: "100vw",
    background: `url(${BackgroundImage})`
}

// const bt1 = {
//     marginTop: '26%',
//     marginLeft: '25%',
//     marginRight: '20px'
// };

// const homeButton = {
//     height: '6%',
//     width: '8%',
//     borderRadius: '20px',
//     fontSize: '17px',
//     boxShadow: '0 4px 8px rgba(143, 207, 241, 0.5)',
//     background: 'linear-gradient(to bottom, #e1ecf4, #73c5fc)'
// };
// const homeButtonHover = {
//     boxShadow: '0 4px 8px rgba(0, 54, 84, 0.5)',
//     background: 'linear-gradient(to bottom, #70bdf4, #02375b)'
// }