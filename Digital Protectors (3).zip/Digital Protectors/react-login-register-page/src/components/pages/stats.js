import React, { Component } from 'react';

import './stats.css';

class Stats extends Component {
  constructor(props) {
    super(props);
    this.state = {
      quote: "Click to get the latest statistics!",
    };
  }

  quotes = [
    "Election Drama in Taiwan: Did you know that over 800 fake Facebook accounts have been caught red-handed, reposting Chinese-language TikTok and YouTube videos about Taiwanese politics? In the context of Taiwanese politics, the content being reposted—Chinese-language TikTok and YouTube videos about Taiwanese politics—raises concerns about potential disinformation or propaganda.",
    "Beware of Impersonators: Market guru Porinju Veliyath has sounded the alarm on X (formerly Twitter), warning his followers about cybercriminals impersonating him to defraud the public. Stay alert!",
    "FTC’s Red Flag on Fake Shipping Notifications: The Federal Trade Commission is waving a red flag about fake invoice and shipping message scams. These scams tend to spike during certain times of the year. Keep an eye out!",
    "2023’s Worst Social Media Scams: A report has spotlighted the worst social media scams of 2023 and how to dodge them. One case involved a scammer posing as a military personnel named “Jim”, who conned a woman named Georgina into sending him over $100,000. Be cautious!",
    "UK Finance Points Finger at Social Media Companies: UK Finance has accused social media companies of profiting from scams on their platforms and has urged them to reimburse victims."
  ];

  changeQuote = () => {
    const randomIndex = Math.floor(Math.random() * this.quotes.length);
    this.setState({ quote: this.quotes[randomIndex] });
  };

  render() {
    return (
      <div>
        <div id="statistics-heading">
          <h1>Statistics</h1>
        </div>
        <div id="quote-container" onClick={this.changeQuote}>
          <p id="quote">{this.state.quote}</p>
        </div>
        <div id="bottom-message">
          <h3>Click to know more such statistics</h3>
        </div>
      </div>
    );
  }
}

export default Stats;
