import React from 'react';
import './news.css'

const news = () => {
  return (
    <div>
      <header style={{ backgroundColor: '#333', color: '#fff', textAlign: 'center', padding: '20px' }}>
        <h1>News and Updates</h1>
      </header>

      <div style={{ maxWidth: '800px', margin: '20px auto', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around' }}>
        <a href="https://news.wfsu.org/all-npr-news/2023-12-13/fake-social-media-accounts-are-targeting-taiwans-presidential-election" className="box" target="_blank" rel="noopener noreferrer">
          <span>Fake social media accounts are targeting taiwans presidential election</span>
        </a>

        <a href="https://www.forbes.com/sites/carolynrosenblatt/2023/12/14/warn-aging-parents-now-about-fake-package-shipping-scams/" className="box" target="_blank" rel="noopener noreferrer">
          <span>Warn aging parents now about fake package shipping scams</span>
        </a>

        <a href="https://www.msn.com/en-us/news/technology/social-media-scam-posing-as-kentucky-state-police/ar-AA1lByGc" className="box" target="_blank" rel="noopener noreferrer">
          <span>Social media scam posing as kentucky state police</span>
        </a>

        <a href="https://www.msn.com/en-us/money/technology/expecting-a-christmas-gift-ftc-warns-of-fake-shipping-notification-invoice-scams/ar-AA1lzXo4" className="box" target="_blank" rel="noopener noreferrer">
          <span>Expecting a christmas gift ftc warns of fake shipping notification invoice scams</span>
        </a>
      </div>
    </div>
  );
};

export default news;
