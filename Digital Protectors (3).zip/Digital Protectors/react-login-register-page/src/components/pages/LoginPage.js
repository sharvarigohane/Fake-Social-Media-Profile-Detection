import React from 'react'
import { Link } from 'react-router-dom'

import '../../App.css'
import './loginPage.css'
import bacVideo from '../../assets/images/WhatsApp Video 2023-12-11 at 23.43.54_4ba5c53c.mp4'
// "C:\Users\ASUS\OneDrive\Desktop\tp\reactmm\react-login-register-page\src\assets\images\WhatsApp Video 2023-12-11 at 23.43.54_4ba5c53c.mp4"

export default function SignInPage() {
    const navigateToExternalPage = () => {
        // Change the URL to the external HTML page
        window.location.href = 'C:/Users/ASUS/OneDrive/Desktop/tp/reactmm/HOME PAGE DESIGN/index.html';
    };
    return (
        <div className='loginDiv'>
            <video autoPlay loop muted playsInline className="background-clip">
                <source src={bacVideo} type="video/mp4" />
            </video>
            <div className="text-center m-5-auto">
                <h2>Sign in</h2>
                <form action="/home">
                    <p>
                        <label>Username or email address</label><br />
                        <input type="text" name="first_name" required />
                    </p>
                    <p>
                        <label>Password</label>
                        <Link to="/forget-password"><label className="right-label">Forget password?</label></Link>
                        <br />
                        <input type="password" name="password" required />
                    </p>
                    <p>
                        <button onClick={navigateToExternalPage} id="sub_btn">Login</button>
                    </p>
                </form>
                <footer>
                    <p>First time? <Link to="/register">Create an account</Link>.</p>
                    <p><Link to="/">Back to Homepage</Link>.</p>
                </footer>
            </div>
        </div>
    )
}


