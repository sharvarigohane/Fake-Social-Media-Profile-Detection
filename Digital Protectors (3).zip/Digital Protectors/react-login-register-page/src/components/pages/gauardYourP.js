import React from 'react'
import third from '../../assets/images/guard3.jpg'
import './guardYourP.css'

export default function gauardYourP() {
    
  return (
    <div className='divvv'>
        <img src={third} alt="" className='imagesss'/>
    </div>
  )
}
