import React, { useState } from 'react';
import './HomePage.css'; // Import your CSS file for styling
import back from '../../assets/images/back.png'
import first from '../../assets/images/1.png'
import second from '../../assets/images/2.png'
import third from '../../assets/images/3.png'
import fourth from '../../assets/images/4.png'
import fifth from '../../assets/images/5.png'
import logo from '../../assets/images/logo.jpg'
import chatBot from '../../assets/images/chatBot.jpg'



const HomePage = () => {
  const [showAdditionalItems, setShowAdditionalItems] = useState(false);

  const toggleAdditionalItems = () => {
    setShowAdditionalItems(!showAdditionalItems);
  };
  const backImg = {
    backgroundImage: `url(${back})`,
    backgroundSize: 'cover',
    backgroundPosition: 'right right',
    backgroundRepeat: 'no-repeat',
    backgroundAttachment: 'fixed',
    margin: 0,
  };

  const [slideIndex, setSlideIndex] = useState(1);

  const plusSlides = (n) => {
    showSlide(slideIndex + n);
  };

  const currentSlide = (n) => {
    showSlide(n);
  };

  const showSlide = (n) => {
    let newIndex = n;
    const slides = document.getElementsByClassName("myslides");
    const dots = document.getElementsByClassName("dots");

    if (newIndex > slides.length) {
      newIndex = 1;
    }

    if (newIndex < 1) {
      newIndex = slides.length;
    }

    setSlideIndex(newIndex);

    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }

    for (let i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
    }

    slides[newIndex - 1].style.display = "block";
    dots[newIndex - 1].className += " active";
  };

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic (e.g., send data to a server)
    console.log('Form submitted:', formData);
  };


  return (
    <div className="backImg">
      <header className="navbar">
        <div className="logo-container">
          <img src={logo} alt="" className='mainImg'/>
          {/* <h1>DigitalP</h1> */}
        </div>
        <nav className="nav-links">
          <a href="#home">Home</a>
          <a href="#aboutUs">About Us</a>
          <a href="#search">Searched Accounts</a>
          <a href="#contact">Contact Us</a>
        </nav>
        <a href='/chat' className="xyzz"> 
          <img src={chatBot} alt="" className='mainImg'/>
          {/* <h1>DigitalP</h1> */}
        </a>
        <div className="hamburger-menu" onClick={toggleAdditionalItems}>
          ☰
          {showAdditionalItems && (
            <div className="additional-items">
              <a href="#">Your Profile</a>
              <a href="#">Notification</a>
              <a href="#">Badges</a>
              <a href="#">Help & Support</a>
              <a href="#">Settings</a>
              <a href="#">Log Out</a>
            </div>
          )}
        </div>
      </header>

      <div id="home">
        <div className="search-container">
          <input type="text" className="search-input" placeholder="Enter Suspected Id....." />
          <div className="search-icon">&#128269;</div>
        </div>

        <div className="slideshow-container">
          <div className="myslides">
            <a href="/stat" target="_blank">
              <div>
                <img src={first} alt="Slide 1" />
              </div>
            </a>
          </div>
          <div className="myslides">
            <a href="/newss" target="_blank">
              <div>
                <img src={second} alt="Slide 1" />
              </div>
            </a>
          </div>
          <div className="myslides">
            <a href="/video" target="_blank">
              <div>
                <img src={third} alt="Slide 1" />
              </div>
            </a>
          </div>
          <div className="myslides">
            <a href="/guard" target="_blank">
              <div>
                <img src={fourth} alt="Slide 1" />
              </div>
            </a>
          </div>
          <div className="myslides">
            <a href="/realFake" target="_blank">
              <div>
                <img src={fifth} alt="Slide 1" />
              </div>
            </a>
          </div>
          <a className="back" onClick={() => plusSlides(-1)}>&#10094;</a>
          <a className="next" onClick={() => plusSlides(1)}>&#10095;</a>
        </div>
        <br />
        <div style={{ textAlign: 'center' }}>
          <span className="dots" onClick={() => currentSlide(1)}></span>
          <span className="dots" onClick={() => currentSlide(2)}></span>
          <span className="dots" onClick={() => currentSlide(3)}></span>
          <span className="dots" onClick={() => currentSlide(4)}></span>
          <span className="dots" onClick={() => currentSlide(5)}></span>
        </div>

      </div>

      <div id='search' className='xyxx'>
        <a href="/searcgAcc" target='="_blank' className='searchDiv'>
          <button class="searchbutton">Search Fake Accounts</button>
        </a>
      </div>

      <div id="aboutUs" className="whiteBox">
        {/* Your content goes here */}
        <h1>About Us</h1>
        <p>Welcome to our dedicated platform committed to addressing the prevalent issue of fake social media accounts! Within our organization, we are a dynamic team comprising six individuals who share a profound passion for upholding online integrity. Our overarching mission revolves around establishing a safer digital landscape through the creation and maintenance of a robust system for detecting and reporting fake social media accounts.

          At the heart of our initiative is the fusion of our collective expertise in technology and cybersecurity. We aspire to empower users like yourself to not only identify but also actively report suspicious activities related to fake social media accounts. In doing so, we aim to cultivate a more secure online environment that benefits everyone who engages with digital platforms.

          The significance of our mission lies in the recognition that the proliferation of digital deception poses a substantial threat to the online community. By leveraging our skills and knowledge, we are determined to contribute to the fight against this deceptive phenomenon. We invite you to join us in this crucial endeavor. Together, we can make a meaningful difference in fostering trust, authenticity, and security across the digital realm. Thank you for being a part of our mission to combat digital deception and create a safer online space for all.</p>
      </div>


      <div id="contact" className="whiteBox">
        {/* Your content goes here */}
        <h1>Contact Us</h1>

        <div className='cont'>
          <form onSubmit={handleSubmit} className='formm'>
            <div className="maincont">
              <div className="firstdiv">
                <label>
                  Name:
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                  />
                </label>
                <br />
                <label>
                  Email:
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                </label>
                <br />
                <label>
                  Message:
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                  />
                </label>
              </div>
              <br />
              <div className='subb'>
                <button type="submit">Submit</button>
              </div>
            </div>
          </form>

          <div>
            <h2>Contact Details</h2>
            <p>Email: contact@example.com</p>
            <p>Phone: +1 (123) 456-7890</p>
            <p>Address: 123 Main St, Cityville</p>
          </div>

        </div>

      </div>


    </div >
  );
};

export default HomePage;
