import React, { useRef, useEffect } from 'react';
import './chatBot.css'; // Import the CSS file for styling

class ChatBot extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      chatMessages: [],
    };
    this.userInputRef = React.createRef();
  }

  sendMessage = () => {
    const userInput = this.userInputRef.current.value;

    // Display user message
    this.setState((prevState) => ({
      chatMessages: [
        ...prevState.chatMessages,
        { type: 'user', content: `You: ${userInput}` },
      ],
    }));

    // Simulate chatbot response (replace with actual logic)
    const botResponse = this.getChatbotResponse(userInput);

    // Display chatbot message
    this.setState((prevState) => ({
      chatMessages: [
        ...prevState.chatMessages,
        { type: 'bot', content: `Chatbot: ${botResponse}` },
      ],
    }));

    // Clear user input
    this.userInputRef.current.value = '';
  };

  getChatbotResponse = (userInput) => {
    userInput = userInput.toLowerCase();

    if (userInput.includes('detect fake profile')) {
      return "Our system uses advanced algorithms to analyze profiles and detect potential fake accounts.";
    } else if (userInput.includes('report a profile')) {
      return "If you suspect a profile is fake, you can report it through our reporting system.";
    } else if (userInput.includes('how does reporting work')) {
      return "When you report a profile, our team reviews the information and takes appropriate action if necessary.";
    } else if (userInput.includes('report anonymously')) {
      return "Yes, you can report profiles anonymously to protect your identity.";
    } else if (userInput.includes('common signs of a fake profile')) {
      return "Common signs of a fake profile include unusual friend requests, limited activity, and suspicious-looking photos.";
    } else if (userInput.includes('protect myself from fake profiles')) {
      return "To protect yourself from fake profiles, avoid sharing personal information, review friend requests cautiously, and regularly review privacy settings.";
    } else if (userInput.includes('friend request from a suspicious account')) {
      return "If you receive a friend request from a suspicious account, do not accept it and report the profile.";
    } else if (userInput.includes('password safety on social media')) {
      return "For password safety on social media, use a strong and unique password, and do not share your password with anyone.";
    } else if (userInput.includes('verify the authenticity of a social media account')) {
      return "To verify the authenticity of a social media account, check for a verified badge, look at the number of followers, and consider contacting the user directly.";
    } else if (userInput.includes('safety tips for online interactions')) {
      return "Safety tips for online interactions include being cautious with personal information, using strong passwords, and reporting suspicious activity.";
    } else if (userInput.includes('how to recognize phishing attempts')) {
      return "To recognize phishing attempts, be skeptical of unsolicited messages, verify sender information, and avoid clicking on suspicious links.";
    } else if (userInput.includes('how to secure my account')) {
      return "To secure your account, enable two-factor authentication, regularly update your password, and monitor account activity.";
    } else {
      return "How can I help you?";
    }
  };

  render() {
    return (
      <div className="chat-container">
        <div className="chat-header">Fake Profile Chatbot</div>
        <div className="chat-messages" id="chatMessages">
          {this.state.chatMessages.map((message, index) => (
            <div key={index} className={`${message.type}-message`}>
              {message.content}
            </div>
          ))}
        </div>
        <div className="chat-input">
          <input
            type="text"
            ref={this.userInputRef}
            className="user-input"
            placeholder="Type your message..."
          />
          <button onClick={this.sendMessage} className="send-button">
            Send
          </button>
        </div>
      </div>
    );
  }
}

export default ChatBot;
