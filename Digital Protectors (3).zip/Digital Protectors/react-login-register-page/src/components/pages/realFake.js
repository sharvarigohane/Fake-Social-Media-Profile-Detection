import React from 'react';
// import './App.css'; // You may want to create a CSS file for your styles

import fake1 from '../../assets/images/fake1.jpg'
import fake2 from '../../assets/images/fake2.jpg'
import fake3 from '../../assets/images/fake3.jpg'
import real1 from '../../assets/images/real1.jpg'
import real2 from '../../assets/images/real2.jpg'
import real3 from '../../assets/images/real3.jpg'
import './realFake.css'


class realFake extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userAnswers: Array(3).fill(null),
    };
  }

  selectImage = (group, selectedImage) => {
    const previousSelections = document.querySelectorAll(`.image-group[data-group="${group}"] img.selected`);
    previousSelections.forEach((img) => img.classList.remove('selected'));

    selectedImage.classList.add('selected');
    this.setState((prevState) => {
      const updatedAnswers = [...prevState.userAnswers];
      updatedAnswers[group - 1] = selectedImage.alt;
      return { userAnswers: updatedAnswers };
    });
  };

  submitAnswers = () => {
    const correctAnswers = ["Image 1A", "Image 2A", "Image 3A"];
    let score = 0;
    let answerText = "<p>Your answers:</p>";

    for (let i = 0; i < correctAnswers.length; i++) {
      if (this.state.userAnswers[i] === correctAnswers[i]) {
        score++;
        answerText += `<p>Group ${i + 1}: Correct</p>`;
      } else {
        answerText += `<p>Group ${i + 1}: Incorrect</p>`;
      }
    }

    document.getElementById("score").innerHTML = `<p>Your score: ${score} out of ${correctAnswers.length}</p>`;
    document.getElementById("answers").innerHTML = answerText;
  };

  render() {
    return (
      <div>
        <h1><b>SPOT WHICH PROFILE IS FAKE!!</b></h1>
        <div id="game-container">
          <div className="image-group" data-group="1">
            <img src={fake1} alt="Image 1A" onClick={(e) => this.selectImage(1, e.target)} />
            <img src={real1} alt="Image 1B" onClick={(e) => this.selectImage(1, e.target)} />
          </div>

          <div className="image-group" data-group="2">
          <img src={real2} alt="Image 2B" onClick={(e) => this.selectImage(2, e.target)} />
            <img src={fake2} alt="Image 2A" onClick={(e) => this.selectImage(2, e.target)} />
            
          </div>

          <div className="image-group" data-group="3">
            <img src={fake3} alt="Image 3A" onClick={(e) => this.selectImage(3, e.target)} />
            <img src={real3} alt="Image 3B" onClick={(e) => this.selectImage(3, e.target)} />
          </div>

          <button id="submit-btn" onClick={this.submitAnswers}>Submit</button>

          <div id="score"></div>

          <div id="answers"></div>
        </div>
      </div>
    );
  }
}

export default realFake;
