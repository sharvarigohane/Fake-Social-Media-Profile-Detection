import React, { Component } from 'react';
import './accSearched.css';

class AccSearched extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formData: {
                status_count: '',
                followers_count: '',
                friends_count: '',
                favourites_count: '',
                lang_num: '',
                listed_count: '',
                geo_enabled: '',
            },
        };
    }

    handleChange = (e) => {
        const { name, value } = e.target;
        this.setState((prevState) => ({
            formData: {
                ...prevState.formData,
                [name]: value,
            },
        }));
    };

    handleSubmit = async (e) => {
        e.preventDefault();

        // Send the request to the backend
        try {
            const response = await fetch('YOUR_BACKEND_API_ENDPOINT', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(this.state.formData),
            });

            if (response.ok) {
                console.log('Request sent successfully');
                // Handle success as needed
            } else {
                console.error('Request failed');
                // Handle failure as needed
            }
        } catch (error) {
            console.error('Error sending request', error);
            // Handle error as needed
        }
    };

    render() {
        return (
            <div className='mainBack'>
                <h1 className='headings'>Enter Accounts Details..</h1>

                <form onSubmit={this.handleSubmit} className='formcss'>
                    <label>
                        Post Count:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Follower Count:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Following Count:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Status Count:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        External Urls:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Language Used:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Mutuals:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    <label>
                        Location:
                        <input
                            type="text"
                            name="status_count"
                            value={this.state.formData.status_count}
                            onChange={this.handleChange}
                        />
                    </label>
                    {/* Repeat the above label and input elements for other parameters */}

                    <button type="submit" className='subButton'>Submit</button>


                </form>
                <p className='para1'>Given Account is % fake</p>

                <p className='para'>Do you want to Report ?</p>

                <div className='xxxx'>
                <a href="/report">
                    <button class="homeButton bt1">Yes</button>
                </a>
                <a href="/home">
                    <button class="homeButton bt1">NO</button>
                </a>
                </div>
            </div>
        );
    }
}

export default AccSearched;
