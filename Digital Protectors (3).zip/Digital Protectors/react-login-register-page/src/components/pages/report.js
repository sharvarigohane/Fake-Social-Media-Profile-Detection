import React, { Component } from 'react';
import './report.css'

class report extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        username: '',
        relationship: '',
        profileDescription: '',
        behavior: '',
        source: '',
        inappropriateContent: '',
        impersonation: '',
        evidence: '',
      },
      imagePreview: null,
    };
  }

  validateForm() {
    for (const key in this.state.formData) {
      if (this.state.formData[key].trim() === '') {
        alert('Please fill in all fields');
        return false;
      }
    }
    return true;
  }

  resetForm() {
    this.setState({
      formData: {
        username: '',
        relationship: '',
        profileDescription: '',
        behavior: '',
        source: '',
        inappropriateContent: '',
        impersonation: '',
        evidence: '',
      },
      imagePreview: null,
    });
  }

  displayImage(e) {
    const input = e.target;
    if (input.files && input.files[0]) {
      const reader = new FileReader();

      reader.onload = function (e) {
        this.setState({ imagePreview: e.target.result });
      }.bind(this);

      reader.readAsDataURL(input.files[0]);
    }
  }

  handleInputChange(e, key) {
    const { value } = e.target;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [key]: value,
      },
    }));
  }

  render() {
    return (
      <div>
        <h2>Instagram Reporting System</h2>

        <form onSubmit={(e) => e.preventDefault()}>

          {/* Your form inputs */}
          {Object.keys(this.state.formData).map((key) => (
            <div key={key}>
              <label htmlFor={key}>{key}:</label>
              {key === 'evidence' ? (
                <div>
                  <textarea
                    id={key}
                    name={key}
                    rows="4"
                    placeholder={`e.g., provide URLs or details`}
                    value={this.state.formData[key]}
                    onChange={(e) => {
                      this.handleInputChange(e, key);
                      this.displayImage(e);
                    }}
                  ></textarea>
                  <input
                    type="file"
                    id={`${key}Image`}
                    name={`${key}Image`}
                    accept="image/*"
                    onChange={(e) => {
                      this.displayImage(e);
                      this.handleInputChange(e, key);
                    }}
                  />
                  <div id="imagePreview">
                    {this.state.imagePreview && <img id="uploadedImage" src={this.state.imagePreview} alt="Uploaded Image" />}
                  </div>
                </div>
              ) : (
                <input
                  type="text"
                  id={key}
                  name={key}
                  placeholder={`e.g., provide ${key} details`}
                  value={this.state.formData[key]}
                  onChange={(e) => this.handleInputChange(e, key)}
                />
              )}
            </div>
          ))}

          <button type="submit" onClick={() => this.validateForm() && alert('Form submitted successfully')}>
            Submit Report
          </button>
          <button type="button" className="reset-btn" onClick={() => this.resetForm()}>
            Reset Form
          </button>
        </form>
      </div>
    );
  }
}

export default report;
