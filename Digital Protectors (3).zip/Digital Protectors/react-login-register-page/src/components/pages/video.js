import React from 'react'
import bacVideo from '../../assets/images/vvv.mp4'
import './loginPage.css'


export default function video() {
    return (
        <div className='loginDiv'>
            <video autoPlay loop muted playsInline className="background-clip">
                <source src={bacVideo} type="video/mp4" />
            </video>
        </div>
    )
}
